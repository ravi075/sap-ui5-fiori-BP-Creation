/* global QUnit */

sap.ui.require(["bpapproval/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
